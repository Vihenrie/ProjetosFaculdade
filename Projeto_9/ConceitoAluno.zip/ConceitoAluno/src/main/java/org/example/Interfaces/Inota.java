package org.example.Interfaces;

public interface Inota {
    String EXCELENTE = "Parabéns, você atingiu todos os indicadores de avaliação com excelência";
    String SATISFATORIO = "Parabéns, você obteve aproveitamento satisfatório nos indicadores de avaliação";
    String INSUFICIENTE = "Você não atingiu o mínimo esperado para aprovação";
}
